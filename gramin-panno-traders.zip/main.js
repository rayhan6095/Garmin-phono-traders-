document.getElementById("root").innerHTML = `
  <h1 style='color:green;'>গ্রামীণ পণ্য ট্রেডার্স</h1>
  <p>এই ওয়েবসাইটটি খুব শীঘ্রই সম্পূর্ণ রূপে তৈরি হবে!</p>
`;